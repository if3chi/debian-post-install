from ulauncher.api.shared.item.SmallResultItem import SmallResultItem
from ulauncher.api.shared.item.ExtensionResultItem import ExtensionResultItem


class ExtensionSmallResultItem(ExtensionResultItem, SmallResultItem):
    pass
